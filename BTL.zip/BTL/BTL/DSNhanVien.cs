﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Diagnostics;

namespace BTL
{
    public partial class DSNhanVien : Form
    {
        public DSNhanVien()
        {
            InitializeComponent();
        }
        
        void setNull()
        {
            tbFullName.Text = "";
            tbDienThoai.Text = "";
            tbAddress.Text = "";
            tbID.Text = "";
            cbBangCap.SelectedIndex = -1;
            dtpNgaySinh.Value = DateTime.Now;
        }

        void ShowNhanVien()
        {
            NhanVien nv = new NhanVien();
            DataTable dt = nv.GetDSNhanVien();
            dgvThongTin.DataSource = dt;
        }

        public void ShowBangCap()
        {
            NhanVien nv = new NhanVien();
            DataTable dt = nv.GetDSBangCap();
            cbBangCap.DataSource = dt;
            cbBangCap.DisplayMember = "TenBangCap";
            cbBangCap.ValueMember = "MaBangCap";
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            NhanVien nv = new NhanVien();
            ShowNhanVien();
            ShowBangCap();
        }

        private void dgvThongTin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow = e.RowIndex;
            if (numrow >= 0)
            {
                tbID.Text = dgvThongTin.Rows[numrow].Cells[0].Value.ToString();
                tbFullName.Text = dgvThongTin.Rows[numrow].Cells[1].Value != null ? dgvThongTin.Rows[numrow].Cells[1].Value.ToString() : "";
                dtpNgaySinh.Text = dgvThongTin.Rows[numrow].Cells[2].Value != null ? dgvThongTin.Rows[numrow].Cells[2].Value.ToString() : "";
                tbAddress.Text = dgvThongTin.Rows[numrow].Cells[3].Value != null ? dgvThongTin.Rows[numrow].Cells[3].Value.ToString() : "";
                tbDienThoai.Text = dgvThongTin.Rows[numrow].Cells[4].Value != null ? dgvThongTin.Rows[numrow].Cells[4].Value.ToString() : "";
                cbBangCap.Text = dgvThongTin.Rows[numrow].Cells[5].Value != null ? dgvThongTin.Rows[numrow].Cells[5].Value.ToString() : "-1";

                btnSua.Enabled = true;
            }
        }
        private void BtThem_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbID.Text != "")
                {
                    DialogResult result = MessageBox.Show("Bạn đang thêm nhân viên đã tồn tại!\nBạn có muốn tiếp tục?",
                        "Thêm nhân viên", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.Cancel)
                    {
                        setNull();
                        return;
                    }
                }
                if (tbFullName.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập tên nhân viên",
                        "Thêm nhân viên", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    tbFullName.Focus();
                    return;
                }
                NhanVien nv = new NhanVien();
                nv.AddNhanVien(
                     tbFullName.Text,
                     dtpNgaySinh.Value.ToShortDateString(),
                     tbAddress.Text,
                     tbDienThoai.Text,
                     Int16.Parse(cbBangCap.SelectedValue.ToString())
                 );
                ShowNhanVien();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,
                        "Thêm nhân viên", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }
        private void btxoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbID.Text == "")
                {
                    MessageBox.Show("Vui lòng chọn nhân viên", "Xóa nhân viên");
                    return;
                }
                if (dgvThongTin.SelectedCells.Count > 0)
                {
                    DialogResult dr = MessageBox.Show("Bạn có chắc xóa nhân viên " + tbFullName.Text + " không?", "Xóa nhân viên", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (dr == DialogResult.OK)
                    {
                        NhanVien nv = new NhanVien();
                        nv.DeleteNhanVien(tbID.Text);
                        ShowNhanVien();
                        setNull();
                    }
                }
                else MessageBox.Show("Vui lòng chọn nhân viên cần xóa");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,
                        "Xóa nhân viên",
                        MessageBoxButtons.OKCancel, 
                        MessageBoxIcon.Error
                );
            }
        }

        private void btluu_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvThongTin.SelectedCells.Count > 0)
                {
                    NhanVien nv = new NhanVien();
                    nv.UpdateNhanVien(
                        Int16.Parse(tbID.Text),
                        tbFullName.Text,
                        dtpNgaySinh.Value.ToShortDateString(),
                        tbAddress.Text,
                        tbDienThoai.Text,
                        Int16.Parse(cbBangCap.SelectedValue.ToString())
                    );
                    //dgvThongTin.SelectedCells.Clear();
                    ShowNhanVien();
                    btnLuu.Enabled = false;
                    btnHuy.Enabled = false;
                    btnThem.Enabled = true;
                    btnXoa.Enabled = true;
                    btnSua.Enabled = true;
                }
                else MessageBox.Show("Vui lòng chọn nhân viên cần sửa", "Sửa nhân viên", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message, 
                    "Sửa nhân viên", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error
               );
            }
        }

    private void btsua_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "")
            {
                MessageBox.Show("Vui lòng chọn nhân viên", "Sửa nhân viên", MessageBoxButtons.OK);
                return;
            }
            btnLuu.Enabled = true;
            btnHuy.Enabled = true;
            btnThem.Enabled = false;
            btnXoa.Enabled = false;
            btnSua.Enabled = false;
        }

        private void bthuy_Click(object sender, EventArgs e)
        {
            btnLuu.Enabled = false;
            btnHuy.Enabled = false;
            btnThem.Enabled = true;
            btnXoa.Enabled = true;
            btnSua.Enabled = true;
        }
        
        private void btnClear_Click(object sender, EventArgs e)
        {
            setNull();
        }
        
    }

}
