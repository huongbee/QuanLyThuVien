﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Diagnostics;

namespace BTL
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            this.AcceptButton = btnLogin;
        }

        private string Sha256Hash(string rawData)
        {
            SHA256 sha256Hash = SHA256.Create();
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = tbUsername.Text;
            string password = tbMatkhau.Text;
            if (username == "" || password == "")
            {
                MessageBox.Show(
                    "Vui lòng nhập đầy đủ thông tin",
                    "Login",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Error
               );
                return;
            }
            Users users = new Users();
            USERS u = users.GetUser(username, Sha256Hash(password));
            if (u == null)
            {
                MessageBox.Show(
                    "Sai thông tin đăng nhập",
                    "Login",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Error
               );
                return;
            }
            Home f = new Home(u.Fullname);
            this.Hide();

            f.ShowDialog();
            this.Close();
        }
    }
}
