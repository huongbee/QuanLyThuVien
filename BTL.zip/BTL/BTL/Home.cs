﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTL
{
    public partial class Home : Form
    {
        string fullname = "";
        public Home(string fullname)
        {
            
            InitializeComponent();
            this.fullname = fullname;
            lbName.Text = "Xin chào, "+fullname;
            //if (this.fullname == "")
            //{
            //    DialogResult r = MessageBox.Show("Vui lòng đăng nhập", "Login", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            //    if (DialogResult.OK == r)
            //    {
            //        Hide();
            //        Login l = new Login();
            //        l.ShowDialog();
            //        //Close();
            //    }
            //    else
            //    {
            //        Application.Exit();
            //    }
            //}
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void eToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach(Form f in MdiChildren)
            {
                f.Close();
            }
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            DSNhanVien f = new DSNhanVien();
            //f.MdiParent = this;
            f.ShowDialog();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DSDocGia f = new DSDocGia();
            //f.MdiParent = this;
            f.ShowDialog();
        }

        private void windowsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DSSach f = new DSSach();
            //f.MdiParent = this;
            f.ShowDialog();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DSPhieuMuon f = new DSPhieuMuon();
           // f.MdiParent = this;
            f.ShowDialog();
        }

        private void Home_Load(object sender, EventArgs e)
        {
           
        }
    }
}
