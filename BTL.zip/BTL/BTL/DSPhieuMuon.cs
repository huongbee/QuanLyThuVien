﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTL
{
    public partial class DSPhieuMuon : Form
    {
        public DSPhieuMuon()
        {
            InitializeComponent();
        }
        void setNull()
        {
            tbID.Text = "";
            dtpNgayMuon.Value = DateTime.Now;
            cbDocgia.SelectedIndex = 0;
        }
        public void ShowPhieuMuon()
        {
            PhieuMuon list = new PhieuMuon();
            dgvThongTin.DataSource = list.GetDSPhieuMuon();
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            setNull();
        }
        public void ShowDocGia()
        {
            PhieuMuon list = new PhieuMuon();
            cbDocgia.DataSource = list.GetDSDocGia();
            cbDocgia.DisplayMember = "HoTenDocGia";
            cbDocgia.ValueMember = "MaDocGia";
        }
        private bool IsFormOpened(string formName)
        {
            FormCollection fc = Application.OpenForms;
            foreach (Form frm in fc)
            {
                if (frm.Text == formName)
                {
                    return true;
                }
            }
            return false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            ChiTietPhieuMuon f = new ChiTietPhieuMuon(-1);
            if (!IsFormOpened(f.Text))
                f.ShowDialog();
            else
            {
                f.Focus();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "")
            {
                MessageBox.Show("Vui lòng chọn phiếu mượn", "Xem chi tiết phiếu mượn", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            ChiTietPhieuMuon f = new ChiTietPhieuMuon(Int16.Parse(tbID.Text));
            f.ShowDialog();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "")
            {
                MessageBox.Show("Vui lòng chọn phiếu mượn", "Sửa phiếu mượn", MessageBoxButtons.OK);
                return;
            }
            btnThem.Enabled = false;
            btnChitiet.Enabled = false;
            btnLuu.Enabled = true;
            btnHuy.Enabled = true;
            btnSua.Enabled = false;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvThongTin.SelectedCells.Count > 0)
                {
                    PhieuMuon d = new PhieuMuon();
                    d.UpdatePhieuMuon(
                        Int16.Parse(tbID.Text),
                        dtpNgayMuon.Value.ToShortDateString(),
                        Int16.Parse(cbDocgia.SelectedValue.ToString())
                    );
                    ShowPhieuMuon();
                    btnChitiet.Enabled = true;
                    btnLuu.Enabled = false;
                    btnHuy.Enabled = false;
                    btnThem.Enabled = true;
                    btnSua.Enabled = true;
                    
                }
                else MessageBox.Show("Vui lòng chọn phiếu mượn cần sửa", "Sửa phiếu mượn");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Sửa phiếu mượn", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            btnLuu.Enabled = false;
            btnHuy.Enabled = false;
            btnThem.Enabled = true;
            btnSua.Enabled = true;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void QLMuonTraSach_Load(object sender, EventArgs e)
        {
            ShowPhieuMuon();
            ShowDocGia();
        }

        private void dgvThongTin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                btnChitiet.Enabled = true;
                int numrow;
                numrow = e.RowIndex;
                if (numrow >= 0)
                {
                    tbID.Text = dgvThongTin.Rows[numrow].Cells[0].Value.ToString();
                    dtpNgayMuon.Text = dgvThongTin.Rows[numrow].Cells[1].Value != null ? dgvThongTin.Rows[numrow].Cells[1].Value.ToString() : "";
                    cbDocgia.Text = dgvThongTin.Rows[numrow].Cells[2].Value != null ? dgvThongTin.Rows[numrow].Cells[2].Value.ToString() : "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Phiếu mượn", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ShowPhieuMuon();
        }
    }
}
