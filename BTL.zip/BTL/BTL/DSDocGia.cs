﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTL
{
    public partial class DSDocGia : Form
    {
        public DSDocGia()
        {
            InitializeComponent();
        }
        
        void setNull()
        {
            tbFullName.Text = "";
            tbAddress.Text = "";
            tbEmail.Text = "";
            tbID.Text = "";
            tbTienno.Text = "0";
            dtpNgaySinh.Value = DateTime.Now;
            dtpNgayhh.Value = DateTime.Now;
            dtpNgayLapthe.Value = DateTime.Now;
        }
        void ShowDocGia()
        {
            DocGia docgia = new DocGia();
            dgvThongTin.DataSource = docgia.GetDSDocGia();
        }
      
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "" || tbID.Text == "0")
            {
                MessageBox.Show("Vui lòng chọn đọc giả", "Sửa đọc giả", MessageBoxButtons.OK);
                return;
            }
            btnLuu.Enabled = true;
            btnHuy.Enabled = true;
            btnThem.Enabled = false;
            btnXoa.Enabled = false;
            btnSua.Enabled = false;
        }

        private void DSDocGia_Load(object sender, EventArgs e)
        {
            ShowDocGia();
        }

        private void dgvThongTin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow = e.RowIndex;
            if (numrow >= 0)
            {
                tbID.Text = dgvThongTin.Rows[numrow].Cells[0].Value.ToString();
                tbFullName.Text = dgvThongTin.Rows[numrow].Cells[1].Value != null ? dgvThongTin.Rows[numrow].Cells[1].Value.ToString() : "";
                dtpNgaySinh.Text = dgvThongTin.Rows[numrow].Cells[2].Value != null ? dgvThongTin.Rows[numrow].Cells[2].Value.ToString() : "";
                tbAddress.Text = dgvThongTin.Rows[numrow].Cells[3].Value != null ? dgvThongTin.Rows[numrow].Cells[3].Value.ToString() : "";
                tbEmail.Text = dgvThongTin.Rows[numrow].Cells[4].Value != null ? dgvThongTin.Rows[numrow].Cells[4].Value.ToString() : "";
                dtpNgayLapthe.Text = dgvThongTin.Rows[numrow].Cells[5].Value != null ? dgvThongTin.Rows[numrow].Cells[5].Value.ToString() : "";
                dtpNgayhh.Text = dgvThongTin.Rows[numrow].Cells[6].Value != null ? dgvThongTin.Rows[numrow].Cells[6].Value.ToString() : "";
                tbTienno.Text = dgvThongTin.Rows[numrow].Cells[7].Value != null ? dgvThongTin.Rows[numrow].Cells[7].Value.ToString() : "0";

                btnSua.Enabled = true;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try { 
                if (tbID.Text != "")
                {
                    DialogResult result = MessageBox.Show("Bạn đang thêm đọc giả đã tồn tại!\nBạn có muốn tiếp tục?",
                        "Thêm đọc giả", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.Cancel)
                    {
                        setNull();
                        return;
                    }
                }
                if (tbFullName.Text =="")
                {
                    MessageBox.Show("Vui lòng nhập tên",
                        "Thêm đọc giả", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    tbFullName.Focus();
                    return;
                }
                DocGia docgia = new DocGia();
                docgia.AddDocGia(
                     tbFullName.Text,
                     dtpNgaySinh.Value.ToShortDateString(),
                     tbAddress.Text,
                     tbEmail.Text,
                     dtpNgayLapthe.Value.ToShortDateString(),
                     dtpNgayhh.Value.ToShortDateString(),
                     int.Parse(tbTienno.Text)
                 );
                ShowDocGia();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                      ex.Message,
                      "Thêm đọc giả",
                      MessageBoxButtons.OK,
                      MessageBoxIcon.Error
                );
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try { 
                if (tbID.Text == "" || tbID.Text == "0")
                {
                    MessageBox.Show("Vui lòng chọn đọc giả", "Xóa đọc giả");
                    return;
                }
                if (dgvThongTin.SelectedCells.Count > 0)
                {
                    DocGia d = new DocGia();
                    if (d.CheckDocGiaHasForeignKey(int.Parse(tbID.Text)))
                    {
                        MessageBox.Show(
                           "Không thể xóa!\nĐọc giả đã tồn tại khóa ngoại",
                           "Xóa đọc giả",
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Error
                       );
                        return;
                    }
                    DialogResult dr = MessageBox.Show("Bạn có chắc xóa đọc giả " + tbFullName.Text + " không?", "Xóa đọc giả", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (dr == DialogResult.OK)
                    {
                        d.DeleteDocGia(int.Parse(tbID.Text));
                        ShowDocGia();
                        setNull();
                    }
                }
                else MessageBox.Show("Vui lòng chọn đọc giả cần xóa");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                      ex.Message,
                      "Xóa đọc giả",
                      MessageBoxButtons.OK,
                      MessageBoxIcon.Error
                );
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvThongTin.SelectedCells.Count > 0)
                {
                    try
                    {
                        DocGia d = new DocGia();
                        d.UpdateDocGia(
                            Int16.Parse(tbID.Text),
                            tbFullName.Text,
                            dtpNgaySinh.Value.ToShortDateString(),
                            tbAddress.Text,
                            tbEmail.Text,
                            dtpNgayLapthe.Value.ToShortDateString(),
                            dtpNgayhh.Value.ToShortDateString(),
                            int.Parse(tbTienno.Text)
                        );
                        ShowDocGia();
                        btnLuu.Enabled = false;
                        btnHuy.Enabled = false;
                        btnThem.Enabled = true;
                        btnXoa.Enabled = true;
                        btnSua.Enabled = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Sửa đọc giả");
                    }
                }
                else MessageBox.Show("Vui lòng chọn đọc giả cần sửa", "Sửa đọc giả");
            }
            catch(Exception ex)
            {
                MessageBox.Show(
                      ex.Message,
                      "Sửa đọc giả",
                      MessageBoxButtons.OK,
                      MessageBoxIcon.Error
                );
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            btnLuu.Enabled = false;
            btnHuy.Enabled = false;
            btnThem.Enabled = true;
            btnXoa.Enabled = true;
            btnSua.Enabled = true;
        }

        private void tbTienno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&  (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            setNull();
        }
    }
}
